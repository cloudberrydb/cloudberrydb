----------------------------------------------
:mod:`pgdb` --- The DB-API Compliant Interface
----------------------------------------------

.. module:: pgdb

Contents
========

.. toctree::
    introduction
    module
    connection
    cursor
    types
    typecache
    adaptation
