About PyGreSQL
==============

.. include:: about.txt