Issue Tracker
-------------

Bug reports and enhancement requests can be posted as
`GitHub issues <https://github.com/PyGreSQL/PyGreSQL/issues/>`_.
