Support
-------

**Python**:
  see http://www.python.org/community/

**PostgreSQL**:
  see http://www.postgresql.org/support/

**PyGreSQL**:
  Join `the PyGreSQL mailing list <https://mail.vex.net/mailman/listinfo/pygresql>`_
  if you need help regarding PyGreSQL.

  You can also ask questions regarding PyGreSQL
  on `Stack Overflow <https://stackoverflow.com/questions/tagged/pygresql>`_.

  Please use `GitHub issues <https://github.com/PyGreSQL/PyGreSQL/issues/>`_
  only for bug reports and enhancement requests,
  not for questions about usage of PyGreSQL.

  Please note that messages to individual developers will generally not be
  answered directly.  All questions, comments and code changes must be
  submitted to the mailing list for peer review and archiving purposes.
